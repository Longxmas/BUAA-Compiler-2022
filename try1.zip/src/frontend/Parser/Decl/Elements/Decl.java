package frontend.Parser.Decl.Elements;

public class Decl {

}
