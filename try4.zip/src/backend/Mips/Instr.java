package backend.Mips;

public interface Instr {

}
