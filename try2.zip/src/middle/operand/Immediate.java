package middle.operand;

public class Immediate implements Operand{
    int value;

    public Immediate(int value) {
        this.value = value;
    }
}
