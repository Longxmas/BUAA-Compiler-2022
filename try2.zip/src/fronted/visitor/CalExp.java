package fronted.visitor;

import fronted.Parser.Expr.Elements.ConstExp;
import fronted.Parser.Expr.Elements.Exp;

public class CalExp {

    public static int CalculateConstExp(ConstExp exp) {
        return 0;
    }

}
