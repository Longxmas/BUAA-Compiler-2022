package fronted.Parser.Decl.Elements;

public class Decl {

}
